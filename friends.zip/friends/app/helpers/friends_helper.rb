module FriendsHelper
end
